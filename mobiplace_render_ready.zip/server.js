
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const multer = require('multer');
const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use('/public', express.static('public'));
app.use('/uploads', express.static('uploads'));

const upload = multer({ dest: 'uploads/' });

const productsFile = './products.json';
const ordersFile = './orders.json';

app.get('/api/products', (req, res) => {
  const data = fs.readFileSync(productsFile);
  res.json(JSON.parse(data));
});

app.post('/api/products', (req, res) => {
  const products = JSON.parse(fs.readFileSync(productsFile));
  const newProduct = { id: Date.now(), ...req.body };
  products.push(newProduct);
  fs.writeFileSync(productsFile, JSON.stringify(products, null, 2));
  res.json(newProduct);
});

app.post('/api/upload', upload.single('image'), (req, res) => {
  if (!req.file) return res.status(400).send("No file uploaded.");
  res.json({ path: `/uploads/${req.file.filename}` });
});

app.get('/api/orders', (req, res) => {
  const data = fs.readFileSync(ordersFile);
  res.json(JSON.parse(data));
});

app.post('/api/orders', (req, res) => {
  const orders = JSON.parse(fs.readFileSync(ordersFile));
  const newOrder = { id: Date.now(), ...req.body };
  orders.push(newOrder);
  fs.writeFileSync(ordersFile, JSON.stringify(orders, null, 2));
  res.json({ success: true });
});

app.post('/api/pay', (req, res) => {
  const { phone, amount } = req.body;
  console.log(`Simulating STK push to ${phone} for KES ${amount}...`);
  console.log(`Paybill: 714888, Account: 285863`);
  res.json({ success: true, message: "STK Push simulated" });
});

app.listen(PORT, () => {
  console.log(`MobiPlace server running at http://localhost:${PORT}`);
});
